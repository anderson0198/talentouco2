package com.example.talentouco2

class TalentoProvider {
    companion object {
        val talentosList = listOf<Talento>(
            Talento(
                "Sergio Posada",
                "Ing. Sistemas",
                "https://scontent.feoh4-4.fna.fbcdn.net/v/t39.30808-6/271183898_5065606940140265_2076158628541722377_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeGBOJXBUbnFzhVbjOTEI3V3TfGjb2II7rFN8aNvYgjusfDr2kHaCngdi49cm_9uoTy-pHF2cVIM1lVvJvOsXZIg&_nc_ohc=KbCEaPCn_UUAX-gWzFy&_nc_ht=scontent.feoh4-4.fna&oh=00_AfD9QJ3S3NGYq8ty5nGELKlKp8clIZM44X-SR3hjS8C0pQ&oe=64E95E03"
            ),
            Talento(
                "Anderson paz",
                "Ing. Sistemas",
                "https://scontent.feoh4-4.fna.fbcdn.net/v/t1.6435-9/33581500_1947506135319423_7518787001261228032_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=84a396&_nc_eui2=AeGj5zd-RxZs5NFwLRrkcknfkK9aOedNlRaQr1o5502VFqGkBIas_dCsJOLZRq2iCOdOt4vChONapHUAGoYZP3UH&_nc_ohc=NzIqkShOrB4AX-WnJ9-&_nc_ht=scontent.feoh4-4.fna&oh=00_AfDcmG7tG7ZhDFtvdI2w2WXn28v2QwJ8spQZjiTnUU3x2w&oe=650CCA2F"
            )
        )
    }
}