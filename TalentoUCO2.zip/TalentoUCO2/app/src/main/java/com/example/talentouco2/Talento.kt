package com.example.talentouco2

data class Talento (
    val nombre:String,
    val carrera:String,
    val foto:String
)
